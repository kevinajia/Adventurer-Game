//
//  RecruitCollectionViewCell.swift
//  group18_assignment6
//
//  Created by Wade Bribach on 4/12/20.
//  Copyright © 2020 Wade Bribach. All rights reserved.
//

import UIKit

class RecruitCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var portraitImageView: UIImageView!

}
