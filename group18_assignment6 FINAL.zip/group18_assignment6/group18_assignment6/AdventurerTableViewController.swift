//
//  AdventurerTableViewController.swift
//  group18_assignment6
//
//  Created by Wade Bribach on 3/20/20.
//  Copyright © 2020 Wade Bribach. All rights reserved.
//

import UIKit
import CoreData

class AdventurerTableViewController: UITableViewController {
    
    var selectedIndex:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        //1 get appdelegate
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        //2
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Adventurer")
        
        //3
        do {
            adventurers = try managedContext.fetch(fetchRequest)
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }

    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return adventurers.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AdventurerCell", for: indexPath) as! AdventurerTableViewCell
        
        let currentAdventurer = adventurers[indexPath.row]
        
        // Configure the cell...
        //cell.nameLabel.text = currentAdventurer.value(forKeyPath: "name") as? String
        //will eventually replace .attribute_name with .value(forKeyPath: "attribute_name") as? attribute_type
        
        //allows for easy delete
        cell.dataIndex = indexPath.row
        
        cell.attackLabel?.text =
            String(format: "%.02f", currentAdventurer.value(forKey: "attackPower") as! Float)
        
        cell.hpLabel.text =
            "\(currentAdventurer.value(forKey: "currentHP") as! Int)/\(currentAdventurer.value(forKey: "maxHP") as! Int)"
        
        cell.nameLabel.text = currentAdventurer.value(forKey: "name") as? String
    
        cell.professionLabel.text = currentAdventurer.value(forKey: "profession") as? String
        
        cell.levelLabel.text = String(currentAdventurer.value(forKey: "level") as! Int)
        
        cell.portraitImageView.image = UIImage(named: currentAdventurer.value(forKey: "portrait") as! String)

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        //remember the index to the selected adventurer cell
        //print(indexPath.row)
        
        selectedIndex = indexPath.row
        
        //call ShowQuestView segue
        performSegue(withIdentifier: "ShowQuestViewSegue", sender: self)
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        
        //only the quest view will need a reference to a selected adventurer
        if let navVC = segue.destination as? UINavigationController {
            if let vc = navVC.viewControllers.first as? QuestViewController {
                // Pass the selected object to the new view controller.
                vc.targetIndex = selectedIndex
            }
        }
    }

    //MARK: Swipe Delete
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
               return
            }
            
            //1 you always need a managed context in order to save data
            let managedContext = appDelegate.persistentContainer.viewContext

            managedContext.delete(adventurers[indexPath.row])
            
            //remove it from the context and then save
            do {
                try managedContext.save()
                adventurers.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: .bottom)
            } catch let error as NSError {
                print("Could not save. \(error), \(error.userInfo)")
            }
            
            //self.tableView.reloadData()
        }
    }
    
    //MARK: Button Delete
    /*
    @IBAction func deleteAdventurer(_ sender: UIButton) {
        
        if let cell = sender.superview?.superview! as? AdventurerTableViewCell {
            
            //send an alert to the user
            let alert = UIAlertController(
                title: "Delete Adventurer",
                message: "Are you sure you want to delete \(String(describing: cell.nameLabel.text!))",
                preferredStyle: .alert
            )
        

            let confirmAction = UIAlertAction(title: "Bro, ofc", style: .default) { [unowned self] action in
                
                guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                   return
                }
                
                //1 you always need a managed context in order to save data
                let managedContext = appDelegate.persistentContainer.viewContext

                managedContext.delete(adventurers[cell.dataIndex])
                
                //remove it from the context and then save
                do {
                    try managedContext.save()
                    adventurers.remove(at: cell.dataIndex)
                } catch let error as NSError {
                    print("Could not save. \(error), \(error.userInfo)")
                }
                
                self.tableView.reloadData()
            }
            
            let cancelAction = UIAlertAction(title: "Chillzzz", style: .cancel)
            
            alert.addAction(confirmAction)
            alert.addAction(cancelAction)
            
            present(alert, animated: true)
        
        }
    }
    */
}
