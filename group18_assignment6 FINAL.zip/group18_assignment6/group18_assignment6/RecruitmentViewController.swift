//
//  RecruitmentViewController.swift
//  group18_assignment6
//
//  Created by Wade Bribach on 3/20/20.
//  Copyright © 2020 Wade Bribach. All rights reserved.
//

import UIKit
import CoreData

//instantiate random statsheet


/*
private func createRandomStats() -> StatSheet {
    return StatSheet(
        attackPower: Float.random(in: 10 ..< 20),
        level: 1,
        profession: "Thug",
        name: "String",
        maxHP: 100,
        currentHP: 100,
        portrait: "default"
    )
}
*/

//easy image name references
private let imageNames = [
    "default",
    "swain",
    "sylas"
]

class RecruitmentViewController: UIViewController {
    
    @IBOutlet weak var newProfessionTextField: UITextField!
    @IBOutlet weak var newNameTextField: UITextField!
    @IBOutlet weak var recruitPortraitCollectionView: UICollectionView!
    
    var selectedPortraitName: String = ""
    
    //this is for configuring selected an unselected states
    var selectedIndexPath = IndexPath()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        //register cells???
        
        //scrub temp data
    }
    
    //when the user presses the save button, call save functionality and unwind
    @IBAction func saveNewAdventurer(_ sender: UIButton) {
        
        //make sure their is an adventurer to save
        if newProfessionTextField.text != "" && newNameTextField.text != "" && selectedPortraitName != "" {
            
            //save new data to data store
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                return
            }
            
            //you always need a managed context in order to save data
            let managedContext = appDelegate.persistentContainer.viewContext
            
            //pull up a new empty adventurer and write their attributes
            let entity = NSEntityDescription.entity(forEntityName: "Adventurer", in: managedContext)!
            let newAdventurer = NSManagedObject(entity: entity, insertInto: managedContext)
            
            newAdventurer.setValue(newNameTextField.text, forKeyPath: "name")
            newAdventurer.setValue(newProfessionTextField.text, forKey: "profession")
            newAdventurer.setValue(selectedPortraitName, forKey: "portrait")
            newAdventurer.setValue(1, forKey: "level")
            newAdventurer.setValue(100,forKey: "maxHP")
            newAdventurer.setValue(100,forKey: "currentHP")
            newAdventurer.setValue(Float.random(in: 10 ..< 20), forKey: "attackPower")
            
            //save changes to the managed context
            do {
                try managedContext.save()
                
                //represent changes to adventurers table
                adventurers.append(newAdventurer)
            } catch let error as NSError {
                print("Could not save. \(error), \(error.userInfo)")
            }
                   
            performSegue(withIdentifier: "ExitRecruitmentSegue", sender: self)
        }
    }
    
    //when the user presses the cancel button, DO NOT save player data and simply return to the previous segue; unwind segue?
    //should probably scrub text field data and reset image selection as well
    @IBAction func cancelRecruitment(_ sender: UIButton) {
        //perform segue
        performSegue(withIdentifier: "ExitRecruitmentSegue", sender: self)
    }
    
    

    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        
        //scrub temp data
        newProfessionTextField.text = ""
        newNameTextField.text = ""
        selectedPortraitName = "default"
        selectedIndexPath = IndexPath()
    }

    
}

extension RecruitmentViewController: UICollectionViewDataSource, UICollectionViewDelegate {

    
    // populate collection view; reference delegate method deque reusable cell;
    // each indexPath.row corrosponds to an image in the image list
    // when the user taps a collection view image, it should be highlighted

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        imageNames.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = recruitPortraitCollectionView.dequeueReusableCell(withReuseIdentifier: "RecruitPortraitCell", for: indexPath) as! RecruitCollectionViewCell
        
        cell.portraitImageView.image = UIImage(named: imageNames[indexPath.row])
        
        if indexPath == selectedIndexPath {
            cell.backgroundColor = UIColor.blue
        }
        
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if selectedIndexPath != indexPath {
            collectionView.cellForItem(at: selectedIndexPath)?.backgroundColor = UIColor.white
        }
        
        collectionView.cellForItem(at: indexPath)?.backgroundColor = UIColor.blue
        
        selectedPortraitName = imageNames[indexPath.row]
        
        selectedIndexPath = indexPath
    }
    
}
