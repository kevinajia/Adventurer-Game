//
//  AdventurerTest.swift
//  group18_assignment6
//
//  Created by Wade Bribach on 3/21/20.
//  Copyright © 2020 Wade Bribach. All rights reserved.
//

import Foundation
import CoreData
import UIKit

var adventurers: [NSManagedObject] = []

/* 
func addAdventurerData(name: String, profession: String, portrait: String) {
    guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
        return
    }
    
    //1 you always need a managed context in order to save data
    let managedContext = appDelegate.persistentContainer.viewContext
    
    //2, retreive the person definition from a NS data model and place it into the managed context
    let entity = NSEntityDescription.entity(forEntityName: "Adventurer", in: managedContext)!
    let newAdventurer = NSManagedObject(entity: entity, insertInto: managedContext)
    
    //3, write values for the new adventurer
    newAdventurer.setValue(name, forKeyPath: "name")
    newAdventurer.setValue(profession, forKey: "profession")
    newAdventurer.setValue(portrait, forKey: "portrait")
    newAdventurer.setValue(1, forKey: "level")
    newAdventurer.setValue(100,forKey: "maxHP")
    newAdventurer.setValue(100,forKey: "currentHP")
    newAdventurer.setValue(Float.random(in: 10 ..< 20), forKey: "attackPower")
    
    //4, catch errors if data save fails
    do {
        try managedContext.save()
        adventurers.append(newAdventurer)
    } catch let error as NSError {
        print("Could not save. \(error), \(error.userInfo)")
    }
}

//delete data by getting the current data context, deleting an entity, and then saving it
func deleteAdventurerData(index: Int) {
    guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
           return
       }
    
    //1 you always need a managed context in order to save data
    let managedContext = appDelegate.persistentContainer.viewContext

    managedContext.delete(adventurers[index])
    
    //remove it from the context and then save?
    do {
        try managedContext.save()
        adventurers.remove(at: index)
    } catch let error as NSError {
        print("Could not save. \(error), \(error.userInfo)")
    }
}

func loadData() {
    //1
    guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
        return
    }
    
    let managedContext = appDelegate.persistentContainer.viewContext
    
    //2
    let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Adventurers")
    
    //3
    do {
        adventurers = try managedContext.fetch(fetchRequest)
    } catch let error as NSError {
        print("Could not fetch. \(error), \(error.userInfo)")
    }
}
 
*/
