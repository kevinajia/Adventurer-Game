//
//  ViewController.swift
//  group18_assignment6
//
//  Created by Wade Bribach on 3/20/20.
//  Copyright © 2020 Wade Bribach. All rights reserved.
//

import UIKit
import CoreData

let monsterNames = [
    "Skillet",
    "Godzilla",
    "Parasite"
]

struct Monster {
    var name: String
    var attackPower: Float
    var hp: Int64
}

//staging struct
struct AdventurerStruct {
    var attackPower: Float
    var level: Int64
    var maxHP: Int64
    var currentHP: Int64
    var name: String
}

class QuestViewController: UIViewController {
    
    var targetIndex: Int = 0
    var currentMonster: Monster = Monster(name: "Skillet", attackPower: 5, hp: 60)
    var adventurerTimer = Timer()
    var monsterTimer = Timer()
    var selectedAdventurer = NSManagedObject()
    var stagedAdventurer = AdventurerStruct(
        attackPower: 1,
        level: 1,
        maxHP: 1,
        currentHP: 1,
        name: "???"
    )

    @IBOutlet weak var portraitImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var levelLabel: UILabel!
    @IBOutlet weak var professionLabel: UILabel!
    @IBOutlet weak var attackLabel: UILabel!
    @IBOutlet weak var hpLabel: UILabel!

    @IBOutlet weak var questLogView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //print(targetIndex)
        selectedAdventurer = adventurers[targetIndex]
        
        stagedAdventurer.attackPower = selectedAdventurer.value(forKey: "attackPower") as! Float
        stagedAdventurer.level = selectedAdventurer.value(forKey: "level") as! Int64
        stagedAdventurer.maxHP = selectedAdventurer.value(forKey: "maxHP") as! Int64
        stagedAdventurer.currentHP = selectedAdventurer.value(forKey: "currentHP") as! Int64
        stagedAdventurer.name = selectedAdventurer.value(forKey: "name") as! String
        
        attackLabel.text = String(format: "%.02f", stagedAdventurer.attackPower)
        
        hpLabel.text = "\(stagedAdventurer.currentHP)/\(stagedAdventurer.maxHP)"
        
        levelLabel.text = String(stagedAdventurer.level)
        
        nameLabel.text = stagedAdventurer.name
    
        professionLabel.text = selectedAdventurer.value(forKey: "profession") as? String
    
        portraitImageView.image = UIImage(named: selectedAdventurer.value(forKey: "portrait") as! String)
        
        // Do any additional setup after loading the view.
        
        //instantiate the timers
        adventurerTimer = Timer.scheduledTimer(timeInterval: 1.5, target: self, selector: #selector(adventurerAttack), userInfo: nil, repeats: true)
        
        monsterTimer = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(monsterAttack), userInfo: nil, repeats: true)
        
        questLogView.text = "Beginning Quest..."
    }

    // prepare for transition back into the recruitment view
    // use unwind action
    // when the user presses the done button
    
    // how to use timers?
    @IBAction func endQuestButton(_ sender: UIButton) {
        performSegue(withIdentifier: "EndQuestSegue", sender: self)
    }
    
    //adventurer action
    @objc func adventurerAttack() {
        
        let damage = Int64(stagedAdventurer.attackPower + Float.random(in: 0 ... stagedAdventurer.attackPower))
        
        questLogView.text += "\n\(stagedAdventurer.name) attacks \(currentMonster.name) for \(damage) damage!"
        
        let newHP = currentMonster.hp - damage
        
        if newHP > 0 {
            currentMonster.hp = newHP
        } else {
            questLogView.text += "\n\(currentMonster.name) was slain!"
            
            //level the adventurer up
            stagedAdventurer.level += 1
            stagedAdventurer.attackPower += Float.random(in: 0.5 ... 2)
            stagedAdventurer.maxHP += Int64(Int.random(in: 5 ... 10))
            
            attackLabel.text = String(format: "%.02f", stagedAdventurer.attackPower)
            hpLabel.text = "\(stagedAdventurer.currentHP)/\(stagedAdventurer.maxHP)"
            levelLabel.text = String(stagedAdventurer.level)
            
            currentMonster = Monster(
                name: monsterNames[Int.random(in: 0 ..< monsterNames.count)],
                attackPower: Float.random(in: 5 ... 10),
                hp: Int64(Int.random(in: 50 ... 100))
            )
            
            questLogView.text += "\n\(currentMonster.name) has appeared!"
        }
    
    }
    
    //monster action
    @objc func monsterAttack() {
        
        //50% chance to do nothing
        let flip = Int.random(in: 0 ... 1)
        
        if flip == 1 {
            //damage the player
            let damage = Int64(currentMonster.attackPower + Float.random(in: 0 ... currentMonster.attackPower))
            
            questLogView.text += "\n\(currentMonster.name) attacks \(stagedAdventurer.name) for \(damage) damage!"
            
            let newHP = stagedAdventurer.currentHP - damage
            
            if newHP > 0 {
                stagedAdventurer.currentHP = newHP
                hpLabel.text = "\(stagedAdventurer.currentHP)/\(stagedAdventurer.maxHP)"
            } else {
                performSegue(withIdentifier: "EndQuestSegue", sender: self)
            }
        } else {
            questLogView.text += "\n\(currentMonster.name) is waiting..."
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //stop timers
        adventurerTimer.invalidate()
        monsterTimer.invalidate()
        
        //store STAGED changes in the data store
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
           return
        }
        
        //1 you always need the managed context in order to manipulate data
        let managedContext = appDelegate.persistentContainer.viewContext
        
        //update nsObject and then save the context
        selectedAdventurer.setValue(stagedAdventurer.level, forKey: "level")
        selectedAdventurer.setValue(stagedAdventurer.maxHP, forKey: "maxHP")
        selectedAdventurer.setValue(stagedAdventurer.maxHP, forKey: "currentHP")
        selectedAdventurer.setValue(stagedAdventurer.attackPower, forKey: "attackPower")

        do {
            try managedContext.save()
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }

}

