//
//  AdventurerTableViewCell.swift
//  group18_assignment6
//
//  Created by Wade Bribach on 3/20/20.
//  Copyright © 2020 Wade Bribach. All rights reserved.
//

import UIKit

class AdventurerTableViewCell: UITableViewCell {
    
    @IBOutlet weak var professionLabel: UILabel!
    @IBOutlet weak var levelLabel: UILabel!
    @IBOutlet weak var attackLabel: UILabel!
    @IBOutlet weak var hpLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var portraitImageView: UIImageView!
    
    var dataIndex = Int()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
